"""
可外接使用的模块：
plotnodes.
    plotdgree_distribution(dgree_distribution_list)
plotgraph.
    plot_nodes_attr(graph_dict,key)
"""